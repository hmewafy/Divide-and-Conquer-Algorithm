
from bracket import single_elimination

def main():
            # create  and running  a smaller example use of  8 teams
           # Prompt for and validate the number of teams
    while True:
        try:
            num_teams = int(input("Enter the number of teams (must be even and > 1): "))
            
            if num_teams <= 1:
                print("Error: Number of teams must be greater than 1.")
            elif num_teams % 2 != 0:
                print("Error: Number of teams must be even.")
            else:
                # Valid input, break out of the loop
                break
        except ValueError:
            print("Error: Please enter a valid integer.")

    teams = [f"T{i}" for i in range(1, num_teams+1 )]
    champion = single_elimination(teams)
    print("Champion is:", champion)

if __name__ == "__main__":
    main()
