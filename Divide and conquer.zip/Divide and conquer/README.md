
Sports Tournament Management System 

How to run the program :
  1) Clone or unzip the  directory.
  2) open and run " main.py" file
  3) Enter the prompt for the  total number of teams, etc.
  4) the program  will promot to enter the winner for each match 
  4) Follow on-screen instructions filling out the winner for each match 
  5) the program will continue to next steps it announces the winner for the last match  the champion

  This is the first verison of the program, we can more functionalty and complexity in future modules.