
from divide_fun import divide 

def single_elimination(teams):
    """
    Conduct a single-elimination tournament with 8 teams using divide and conquer.
    """
    # Base case:
    if len(teams) == 1:
        return teams[0]                         # Only 1 team the  champion

    # Divide
    pairs = divide(teams)

    # conquer (get winners):
    winners = []
    for match in pairs:
        # play_match returns winner of (teamA, teamB)
        winner = play_match(match[0], match[1])
        winners.append(winner)

    # Combine (recurse)  winners form the next round:
    return single_elimination(winners)

def play_match(teamA, teamB):
    """
    Prompts the user to enter a winner between teamA and teamB,
    allowing only teamA or teamB as valid inputs.
    
    """
    while True:
     print(f"Match: {teamA} vs {teamB}")
     winner = input("Enter winner: ").strip()

     if winner == teamA or winner == teamB:
      return winner
     else:
        print(f"Invalid winner! Please enter either '{teamA}' or '{teamB}'.\n")
