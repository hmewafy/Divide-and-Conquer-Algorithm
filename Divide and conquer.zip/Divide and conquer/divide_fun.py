
def divide(teams):
    """
    Intent: Split teams into pairs for the current round of matches.

    PRECONDITION 1: len(teams) >= 2
    PRECONDITION 2: len(teams) is even
    RETURNS: A list of pairs (tuples), e.g., [(T1, T2), (T3, T4), ...]

    POST1: each team is in exactly one pair.
    POST2: The number of pairs is len(teams)/2.
    """
    matches = []
    for i in range(0, len(teams), 2):
        matches.append((teams[i], teams[i+1]))
    return matches
